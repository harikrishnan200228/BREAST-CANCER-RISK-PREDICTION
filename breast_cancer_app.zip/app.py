
import streamlit as st
import joblib
import numpy as np

# Load model
model = joblib.load("model.pkl")

st.title("Breast Cancer Risk Prediction")

st.markdown("Input the values below to predict the likelihood of breast cancer.")

# Collect user input
def user_input():
    features = []
    for feature_name in [
        "mean radius", "mean texture", "mean perimeter", "mean area", "mean smoothness",
        "mean compactness", "mean concavity", "mean concave points", "mean symmetry",
        "mean fractal dimension", "radius error", "texture error", "perimeter error",
        "area error", "smoothness error", "compactness error", "concavity error",
        "concave points error", "symmetry error", "fractal dimension error", "worst radius",
        "worst texture", "worst perimeter", "worst area", "worst smoothness",
        "worst compactness", "worst concavity", "worst concave points", "worst symmetry",
        "worst fractal dimension"
    ]:
        value = st.number_input(f"{feature_name}", value=0.0)
        features.append(value)
    return np.array([features])

# Prediction
if st.button("Predict"):
    input_data = user_input()
    prediction = model.predict(input_data)[0]
    prob = model.predict_proba(input_data)[0][1]

    if prediction == 0:
        st.error(f"🔴 High Risk of Cancer (Malignant) — Probability: {prob:.2f}")
    else:
        st.success(f"🟢 Low Risk (Benign) — Probability: {prob:.2f}")
